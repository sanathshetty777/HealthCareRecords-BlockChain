import React, { useState, useEffect } from 'react';
import { ethers } from 'ethers';

const Healthcare = () => {
  const [provider, setProvider] = useState(null);
  const [signer, setSigner] = useState(null);
  const [contract, setContract] = useState(null);
  const [account, setAccount] = useState(null);
  const [isOwner, setIsOwner] = useState(false);
  const [error, setError] = useState(null);
  const [providerAddress,setProviderAddress] =useState("");
  const [patientID, setPatientID] = useState('');
 const [patientRecords, setPatientRecords] = useState([]);
 const [diagnosis, setDiagnosis] = useState('');
const [treatment, setTreatment] = useState('');


  const ContractAddress = '0x60dd4ac7b9993d081bd22b967a02461aea55073d';

  const contractABI = [
    {
      inputs: [
        { internalType: 'uint256', name: 'patientID', type: 'uint256' },
        { internalType: 'string', name: 'patientName', type: 'string' },
        { internalType: 'string', name: 'diagnosis', type: 'string' },
        { internalType: 'string', name: 'treatment', type: 'string' },
      ],
      name: 'addRecord',
      outputs: [],
      stateMutability: 'nonpayable',
      type: 'function',
    },
    {
      inputs: [{ internalType: 'address', name: 'provider', type: 'address' }],
      name: 'authorizeProvider',
      outputs: [],
      stateMutability: 'nonpayable',
      type: 'function',
    },
    {
      inputs: [],
      stateMutability: 'nonpayable',
      type: 'constructor',
    },
    {
      inputs: [],
      name: 'getOwner',
      outputs: [{ internalType: 'address', name: '', type: 'address' }],
      stateMutability: 'view',
      type: 'function',
    },
    {
      inputs: [{ internalType: 'uint256', name: 'patientID', type: 'uint256' }],
      name: 'getpatientRecords',
      outputs: [
        {
          components: [
            { internalType: 'uint256', name: 'recordID', type: 'uint256' },
            { internalType: 'string', name: 'patientName', type: 'string' },
            { internalType: 'string', name: 'diagnosis', type: 'string' },
            { internalType: 'string', name: 'treatment', type: 'string' },
            { internalType: 'uint256', name: 'timestamp', type: 'uint256' },
          ],
          internalType: 'struct HealthcareRecords.Record[]', // Fixed typo
          name: '',
          type: 'tuple[]',
        },
      ],
      stateMutability: 'view',
      type: 'function',
    },
  ];

  useEffect(() => {
    const connectWallet = async () => {
      try {
        // Check if MetaMask or another wallet is installed
        if (!window.ethereum) {
          throw new Error('No wallet detected. Please install MetaMask.');
        }

        // Set up provider and request accounts
        const provider = new ethers.providers.Web3Provider(window.ethereum);
        await provider.send('eth_requestAccounts', []);
        const signer = provider.getSigner();
        const accountAddress = await signer.getAddress();

        // Set states
        setProvider(provider);
        setSigner(signer);
        setAccount(accountAddress);

        // Initialize contract with signer
        const contract = new ethers.Contract(ContractAddress, contractABI, signer);
        setContract(contract);

        // Get owner and check if connected account is owner
        const ownerAddress = await contract.getOwner();
        setIsOwner(accountAddress.toLowerCase() === ownerAddress.toLowerCase());
      } catch (error) {
        console.error('Error connecting to wallet:', error);
        setError(error.message || 'Failed to connect to wallet');
      }
    };

    connectWallet();
  }, []);

  const fetchPatientRecords = async () => {
    try {
        const records = await contract.getpatientRecords(patientID);
        console.log(records);
        setPatientRecords(records);
    }catch (error) {
        console.error('Error fetching patient records:', error);
        
        }
  }
  const addRecord = async () => {
    try {
        const tx = await contract.addRecord(patientID, "Alice", diagnosis, treatment);
        await tx.wait(); // Wait for the transaction to be mined
        fetchPatientRecords();
        await tx.wait(); // Wait for the transaction to be mined
        

    } catch (error) {
        console.error('Error adding record:', error);
    }
  }



  const authorizeProvider = async () => {
    if(isOwner) {
        try {
            const tx = await contract.authorizeProvider(providerAddress);
            await tx.wait(); // Wait for the transaction to be mined
            alert(`Provider ${providerAddress} authorized successfully!`);
        }
        catch(error) {
            console.error("only contract owner can authorise different providers",error)
        }
    } else {
    alert("Only contract owner can authorise different providers")
}
}

  return (
    <div className="container">
      <h1 className="title">Healthcare Application</h1>
      {error && <p className="error">{error}</p>}
      {account ? (
        <p className="account-info">Connected Account: {account}</p>
      ) : (
        <p className="account-info">Not connected</p>
      )}
      {isOwner && <p className="owner-info">You are the contract owner</p>}
    <div className='form-section'>
    <h2>Fetch Patient Records </h2>
    
    <input className='input-field' type='text' placeholder='Enter Patient ID' value= {patientID} onChange={(e) => setPatientID(e.target.value)}/>
    <button className='action-button' onClick={fetchPatientRecords}>FetchRecords</button>

    </div>

    <div className="form-section">
    <h2>Add Patient Record</h2>
    <input className='input-field' type='text' placeholder='Diagnosis' value= {diagnosis} onChange={(e) => setDiagnosis(e.target.value)}/>
    <input className='input-field' type='text' placeholder='Treatment' value= {treatment} onChange={(e) => setTreatment(e.target.value)}/>
    <button className='action-button' onClick={addRecord}>Add Records</button>

    </div>
    

      <div className='form-section'>
        <h2>Authorise Healthcare provider</h2>
        <input className='input-field' type= "text" placeholder='Provider Address' value = {providerAddress} onChange={(e) => setProviderAddress(e.target.value)}
        />
        <button className='action-button' onClick={authorizeProvider}>Authorize Provider</button>
    </div>

    <div className='records-section'>
    <h2>Patient records</h2>
    {patientRecords.map((record,index)=>  (
        <div key={index}>
            <p>Record Id; {record.recordID.toNumber()}</p>
            <p>Diagnosis; {record.diagnosis}</p>
            <p>Treatment; {record.treatment}</p>
            <p>Timestamp; {new Date(record.timestamp.toNumber() * 1000).toLocaleString()}</p>
        </div>
    )   )}

      </div>
    </div>

    

  );
};

export default Healthcare;